document.getElementById("contatoForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const nome = document.getElementById("nome").value.trim();
  const email = document.getElementById("email").value.trim();
  const telefone = document.getElementById("telefone").value.trim();
  const tipoContato = document.getElementById("tipoContato").value;
  const mensagem = document.getElementById("mensagem").value.trim();
  const termos = document.getElementById("termos").checked;
  const feedback = document.getElementById("feedback");

  feedback.className = 'feedback';
  feedback.style.display = 'none';

  if (!nome || !email || !tipoContato || !mensagem || !termos) {
    feedback.textContent = "Preencha todos os campos obrigatórios e aceite os termos.";
    feedback.classList.add("error");
    feedback.style.display = "block";
    return;
  }

  const telefoneInput = document.getElementById("telefone");
  if (telefone && !telefoneInput.checkValidity()) {
    feedback.textContent = "Telefone inválido. Use o formato (XX) XXXXX-XXXX.";
    feedback.classList.add("error");
    feedback.style.display = "block";
    return;
  }

  feedback.textContent = "Mensagem enviada com sucesso!";
  feedback.classList.add("success");
  feedback.style.display = "block";

  console.log("Dados enviados:", {
    nome,
    email,
    telefone,
    tipoContato,
    mensagem,
    termosAceitos: termos
  });

  setTimeout(() => {
    feedback.style.display = 'none';
    e.target.reset();
  }, 3000);
});
